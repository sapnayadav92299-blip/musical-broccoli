package dev.lelonio.square.playback

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import kotlin.math.abs

/**
 * Headphones or earbuds back in, the music back on.
 *
 * Taking them out stops the music, so that it does not go on out loud; this is
 * the other half of that. It brings the music back when the same song is still
 * where it was left and headphones are connected again soon after. That is
 * deliberately narrow, because starting sound by itself is something to do
 * only when it is plainly what was wanted:
 *  - only if the music was playing when the headphones went,
 *  - only within [WINDOW_MS] of that,
 *  - only if nothing has been played, skipped or sought since (the same song, at
 *    the same place),
 *  - and only when what comes back is headphones, a cable, Bluetooth or USB:
 *    never the phone's speaker.
 *
 * Works on whichever player the session has, so it is the same for every source.
 * Everything here runs on the main thread, which is where the player lives.
 */
class ResumeOnReconnect(
    context: Context,
    private val player: () -> Player?,
) {

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var started = false
    private var stopped = false

    /** When the headphones went, on the elapsed clock; 0 when there is nothing to come back to. */
    private var leftAt = 0L
    private var mediaId: String? = null
    private var positionMs = 0L

    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != AudioManager.ACTION_AUDIO_BECOMING_NOISY) return
            val p = player()
            val playing = p != null && (p.isPlaying || p.playWhenReady) &&
                p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
            if (!playing || p == null) {
                forget()
                return
            }
            leftAt = SystemClock.elapsedRealtime()
            mediaId = p.currentMediaItem?.mediaId
            positionMs = p.currentPosition
        }
    }

    fun start() {
        if (started) return
        started = true
        // Before the players' own receivers, which are added once something
        // plays: this one has to see the music still going, not already stopped.
        ContextCompat.registerReceiver(
            appContext,
            noisy,
            IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        AudioRoute.start(appContext)
        AudioRoute.onChange { output -> onRoute(output) }
    }

    fun stop() {
        stopped = true
        main.removeCallbacksAndMessages(null)
        if (started) runCatching { appContext.unregisterReceiver(noisy) }
        forget()
    }

    private fun onRoute(output: AudioRoute.Output) {
        if (stopped || leftAt == 0L) return
        if (!ChannelBalance.isHeadphones(output.kind)) return
        if (SystemClock.elapsedRealtime() - leftAt > WINDOW_MS) {
            forget()
            return
        }
        // The system is still moving the sound over when this is announced.
        main.removeCallbacksAndMessages(null)
        main.postDelayed(::resume, SETTLE_MS)
    }

    private fun resume() {
        if (stopped || leftAt == 0L) return
        val p = player() ?: return
        val elapsed = SystemClock.elapsedRealtime() - leftAt
        val untouched = p.currentMediaItem?.mediaId == mediaId &&
            abs(p.currentPosition - positionMs) <= POSITION_SLACK_MS
        val ready = p.mediaItemCount > 0 && !p.playWhenReady &&
            p.playbackState != Player.STATE_IDLE && p.playbackState != Player.STATE_ENDED
        val stillHeadphones = ChannelBalance.isHeadphones(AudioRoute.current.value.kind)
        forget()
        if (elapsed <= WINDOW_MS && untouched && ready && stillHeadphones) {
            android.util.Log.i("SquareResume", "headphones back, resuming")
            p.play()
        }
    }

    private fun forget() {
        leftAt = 0L
        mediaId = null
        positionMs = 0L
    }

    private companion object {
        /** How long after taking them out that putting them back still means "carry on". */
        const val WINDOW_MS = 120_000L
        const val SETTLE_MS = 400L

        /** The pause lands a moment after the broadcast; more than this is the song having moved. */
        const val POSITION_SLACK_MS = 4_000L
    }
}
