package dev.lelonio.square.widget

import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import dev.lelonio.square.playback.PlaybackService

/**
 * Play and pause from the pull-down panel: a tile the listener can add there.
 *
 * Not in the app, and nothing in the app changes for it. What it shows is what
 * the home-screen widget already keeps of the song (see [SquareWidget]); a press
 * is handed to the player through a controller, the way the widget's buttons are,
 * and for the same reason: connecting starts the playback service as an ordinary
 * bound one, which a media key sent to it with nothing loaded would not.
 */
class PlayTileService : TileService() {

    private val main = Handler(Looper.getMainLooper())

    override fun onStartListening() {
        super.onStartListening()
        draw(playing = kept(this).first, title = kept(this).second)
    }

    override fun onClick() {
        super.onClick()
        val app = applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val controller = runCatching { future.get() }.getOrNull()
            var nowPlaying = false
            try {
                if (controller != null) {
                    // Asked before the press: the player reports its change a
                    // moment later, and the tile shows what was asked for.
                    val was = controller.isPlaying
                    if (was) controller.pause() else controller.play()
                    nowPlaying = !was
                }
            } finally {
                controller?.release()
            }
            // The tile answers at once rather than waiting for the player to
            // report back: what it shows is what the press asked for.
            main.post { draw(playing = nowPlaying, title = kept(app).second) }
        }, MoreExecutors.directExecutor())
    }

    private fun draw(playing: Boolean, title: String?) {
        val tile = qsTile ?: return
        tile.state = if (playing) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = title?.takeIf { it.isNotBlank() }
                ?: getString(dev.lelonio.square.R.string.play)
        }
        tile.updateTile()
    }

    private companion object {
        /** Whether music is playing and what it is, as the widget last drew them. */
        fun kept(context: Context): Pair<Boolean, String?> {
            val prefs = context.getSharedPreferences("square_widget", Context.MODE_PRIVATE)
            return prefs.getBoolean("playing", false) to prefs.getString("title", null)
        }
    }
}
