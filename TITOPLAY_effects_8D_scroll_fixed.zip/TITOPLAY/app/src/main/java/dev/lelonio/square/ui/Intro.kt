package dev.lelonio.square.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.lelonio.square.R
import kotlin.math.PI
import kotlin.math.sin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * The opening of the app: the logo, lit and set in motion, on black.
 *
 * In order, and overlapping:
 *  - the logo's ring turns once round, and two slow clouds of its own colours
 *    swell behind it and settle;
 *  - a band of light crosses the mark, lighting only the mark itself;
 *  - as the ring comes home the mark gives a small pulse;
 *  - the name settles under it, its letters drawing in from wide to set, with a
 *    line of the logo's colours growing beneath.
 *
 * The mark is on screen from the first frame, at the size of the window that
 * the system draws before this one, so nothing blinks between the two. A tap
 * ends it early. [onFinished] is called once, when it is over or skipped.
 */
@Composable
fun IntroSplash(onFinished: () -> Unit, modifier: Modifier = Modifier) {
    val ringTurn = remember { Animatable(0f) }
    val sweep = remember { Animatable(0f) }
    val nameIn = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val context = LocalContext.current
    val sound = remember { SoundHolder() }

    LaunchedEffect(Unit) {
        coroutineScope {
            // The sound, from the first frame, on the animation's own clock: see
            // IntroSound. It adds nothing to what is drawn.
            launch { sound.began(IntroSound.start(context)) }
            launch { ringTurn.animateTo(360f, tween(1100, easing = FastOutSlowInEasing)) }
            launch {
                delay(250)
                sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
            }
            launch {
                delay(300)
                nameIn.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
            }
            launch {
                delay(900)
                burst.animateTo(1f, tween(700, easing = LinearOutSlowInEasing))
            }
        }
        delay(200)
        onFinished()
    }

    val drift = rememberInfiniteTransition(label = "introDrift")
    val cloudTurn by drift.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "cloudTurn",
    )

    Box(
        modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { detectTapGestures { sound.skipped(); onFinished() } },
        contentAlignment = Alignment.Center,
    ) {
        // Two clouds of the logo's colours, turning slowly against each other.
        Canvas(
            Modifier
                .size(360.dp)
                .graphicsLayer { rotationZ = cloudTurn },
        ) {
            val glow = 0.35f + 0.65f * sin(ringTurn.value / 360f * PI.toFloat())
            val reach = size.minDimension / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MAGENTA.copy(alpha = 0.34f * glow), Color.Transparent),
                    center = Offset(size.width * 0.36f, size.height * 0.5f),
                    radius = reach * 0.8f,
                ),
                radius = reach,
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(CYAN.copy(alpha = 0.30f * glow), Color.Transparent),
                    center = Offset(size.width * 0.64f, size.height * 0.5f),
                    radius = reach * 0.8f,
                ),
                radius = reach,
            )
        }

        Box(Modifier.size(178.dp)) {
            Image(
                painter = painterResource(R.drawable.splash_mark),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        // A small breath as the ring comes home.
                        val pulse = 1f + 0.045f * sin(burst.value * PI.toFloat())
                        scaleX = pulse
                        scaleY = pulse
                        compositingStrategy = CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        val s = sweep.value
                        if (s > 0f && s < 1f) {
                            // A band of light across the mark; SrcAtop keeps it
                            // to the mark's own pixels.
                            val w = size.width
                            val x = -w * 0.5f + w * 2f * s
                            drawRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.White.copy(alpha = 0.55f),
                                        Color.Transparent,
                                    ),
                                    start = Offset(x - w * 0.25f, 0f),
                                    end = Offset(x + w * 0.25f, size.height * 0.5f),
                                ),
                                blendMode = BlendMode.SrcAtop,
                            )
                        }
                    },
            )
            Image(
                painter = painterResource(R.drawable.splash_ring),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        rotationZ = ringTurn.value
                        val settle = 0.94f + 0.06f * (ringTurn.value / 360f)
                        scaleX = settle
                        scaleY = settle
                    },
            )
        }

        // The name, set like an engraver's capitals: drawn in from wide
        // spacing to set, rising a little as it appears.
        val t = nameIn.value
        Text(
            "TITOPLAY",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (18f - 9f * t).sp,
            modifier = Modifier
                .offset(y = 150.dp)
                .graphicsLayer {
                    alpha = t
                    translationY = (1f - t) * 12.dp.toPx()
                },
        )
        // A line of the logo's colours growing out from the middle beneath it.
        Box(
            Modifier
                .offset(y = 180.dp)
                .width(96.dp)
                .height(2.dp)
                .graphicsLayer {
                    scaleX = nameIn.value
                    alpha = nameIn.value
                }
                .background(Brush.horizontalGradient(listOf(CYAN, VIOLET, MAGENTA))),
        )
    }
}

private val MAGENTA = Color(0xFFFF3EA5)
private val CYAN = Color(0xFF00E5FF)
private val VIOLET = Color(0xFF9B5CFF)

/**
 * Where the opening's sound is kept, so that a tap which skips the opening can
 * end it, even if the tap comes before the sound has started.
 */
private class SoundHolder {
    private var handle: IntroSound.Handle? = null
    private var skip = false

    fun began(started: IntroSound.Handle?) {
        handle = started
        if (skip) started?.stop()
    }

    fun skipped() {
        skip = true
        handle?.stop()
    }
}
