package dev.lelonio.square.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The sound of the opening: sound and nothing else, and only the turning of it.
 *
 * While the ring turns and the light crosses the mark, air sweeps up from low to
 * bright with a soft tone climbing under it, swelling as the ring comes round and
 * dying away as it settles. Nothing sounds when the name appears: no hit, no
 * chime.
 *
 * Nothing is stored in the app: the sound is worked out the moment it is wanted,
 * in a few milliseconds, from the numbers below.
 *
 * It stays quiet when the phone is on silent or vibrate, when music is already
 * playing, and when the media volume is down.
 */
object IntroSound {

    private const val SAMPLE_RATE = 44_100
    private const val SECONDS = 1.5

    /** A running sound, to be let go of early if the opening is skipped. */
    class Handle internal constructor(private val track: AudioTrack) {
        private val main = Handler(Looper.getMainLooper())

        @Volatile
        private var ended = false

        /** Ends the sound at once, in a short fade so that it does not click. */
        fun stop() {
            if (ended) return
            ended = true
            val steps = 5
            for (i in 1..steps) {
                main.postDelayed({
                    runCatching { track.setVolume(1f - i / steps.toFloat()) }
                    if (i == steps) runCatching { track.stop(); track.release() }
                }, i * 14L)
            }
        }

        internal fun release() {
            if (ended) return
            ended = true
            runCatching { track.release() }
        }
    }

    /**
     * Starts the sound, or returns null if it is not to be heard just now.
     * Works the sound out on a background thread; the sound starts as soon as it is ready.
     */
    suspend fun start(context: Context): Handle? = withContext(Dispatchers.Default) {
        runCatching {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return@runCatching null
            if (audio.isMusicActive) return@runCatching null
            if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) return@runCatching null

            val pcm = synthesize()
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()

            val handle = Handle(track)
            // Let go of it once it has played out.
            Handler(Looper.getMainLooper()).postDelayed({ handle.release() }, (SECONDS * 1000).toLong() + 400L)
            handle
        }.getOrNull()
    }

    private fun smoothstep(a: Double, b: Double, x: Double): Double {
        if (b == a) return if (x >= b) 1.0 else 0.0
        val t = min(1.0, max(0.0, (x - a) / (b - a)))
        return t * t * (3.0 - 2.0 * t)
    }

    private fun synthesize(): ShortArray {
        val n = (SAMPLE_RATE * SECONDS).toInt()
        var seed = 22222L
        var glidePhase = 0.0
        var low = 0.0
        var band = 0.0
        val pcm = ShortArray(n)

        for (i in 0 until n) {
            val t = i / SAMPLE_RATE.toDouble()

            // Swells in as the ring starts to turn, and dies away as it settles.
            val rise = smoothstep(0.0, 0.70, t) * (1.0 - smoothstep(0.78, 1.25, t))

            // Air sweeping up through a narrow band, from low to bright, and a tone
            // climbing two octaves under it.
            seed = (seed * 1664525L + 1013904223L) and 0xFFFFFFFFL
            val noise = (seed shr 8).toDouble() / 8388608.0 - 1.0
            val sweep = smoothstep(0.0, 1.0, t)
            val centre = 350.0 * (4200.0 / 350.0).pow(sweep)
            val f = 2.0 * sin(PI * centre / SAMPLE_RATE)
            low += f * band
            val high = noise - low - 0.35 * band
            band += f * high
            val whoosh = band * rise * 0.55
            val glide = 220.0 * 4.0.pow(sweep)
            glidePhase += 2.0 * PI * glide / SAMPLE_RATE
            val tone = (sin(glidePhase) * 0.07 + sin(glidePhase * 2.0) * 0.025) * rise

            // Softly limited, quick in, a long fade out.
            val fadeIn = min(1.0, t / 0.02)
            val left = min(1.0, (SECONDS - t) / 0.25)
            val fadeOut = if (left < 1.0) 0.5 - 0.5 * cos(PI * max(0.0, left)) else 1.0
            val v = tanh((whoosh + tone) * 1.1) * fadeIn * fadeOut * 0.62
            pcm[i] = (v.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
        }
        return pcm
    }
}
