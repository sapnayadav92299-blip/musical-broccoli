package dev.lelonio.square.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import dev.lelonio.square.playback.AudioPulse
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow

/**
 * A neon light that runs round the edge of the pill while music plays: one light,
 * the way Google's own glows when it is thinking.
 *
 * It is a single line. In a quiet passage it is a stretch of the edge with a
 * bright head and a tail behind it, running round; as the sound grows the tail
 * grows with it, and at full sound it takes the whole of the pill, so that there
 * is no running round left to see, only the colour moving through it: the line
 * is lit all the way and its colours flow along it, blue into violet into pink
 * into amber into green into cyan and round again.
 *
 * The track is the pill's outline with its two long sides bowed gently inward, so
 * that the light does not run along a straight line: it curves down into the pill
 * and back out to the edge on each side, and goes round the ends as the pill does.
 *
 * Drawn the way a gradient is drawn, not as a string of beads. The outline of a
 * pill is two long sides and two half circles, and along each of those the
 * position on the outline is exactly a position on one gradient: a linear one
 * along a straight side, a sweep one round a half circle. So the light is laid
 * down as four unbroken strokes, each filled with one gradient that carries the
 * colour and the fade for that stretch: no pieces, no joins, no dots.
 *
 * Built like a neon tube: a thin crisp tube of colour with a hotter, nearly white
 * centre, and round it two soft layers of glow that add their light to what is
 * behind, the wider spilling outside the pill's edge.
 *
 * Made to move smoothly above all. Its speed, its length and its colour follow
 * the strength of the sound, and each is eased slowly, so that none of them ever
 * steps; the beat does not move it at all, it only makes the light breathe,
 * brighter and a little thicker for a moment. Every movement is taken from the
 * time between frames, so it is the same speed on any phone. See [AudioPulse].
 *
 * It follows the outline at an even speed, takes no touches, and when the music
 * stops it fades out and its frame loop stops with it.
 *
 * Drawn on the edge and past it, so it has to be put outside anything that clips
 * to the pill's own bounds.
 */
@Composable
fun Modifier.neonRing(active: Boolean): Modifier {
    var lap by remember { mutableFloatStateOf(0f) }
    var hue by remember { mutableFloatStateOf(0f) }
    var glow by remember { mutableFloatStateOf(0f) }
    var reach by remember { mutableFloatStateOf(0f) }
    var pulse by remember { mutableFloatStateOf(0f) }
    val appear by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(450),
        label = "neon-appear",
    )

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        var speed = BASE_LAPS
        var drift = BASE_DRIFT
        while (true) {
            val frame = withFrameNanos { it }
            val dt = if (last == 0L) 0f else ((frame - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = frame

            val level = AudioPulse.level()
            val kick = AudioPulse.kick()

            // How fast it runs round follows how strong the sound is, and nothing
            // else: no throw forward on a beat, which is what a jerk looks like.
            // Eased slowly, so the speed is a swell and never a step.
            val wanted = BASE_LAPS + LEVEL_LAPS * level
            speed += (wanted - speed) * (1f - exp(-dt * 3f))
            lap = (lap + speed * dt) % 1f

            // Runs of the palette a second: the colour is always flowing, a little
            // quicker with the sound.
            val drifting = BASE_DRIFT + LEVEL_DRIFT * level
            drift += (drifting - drift) * (1f - exp(-dt * 3f))
            hue = (hue + drift * dt) % 1f

            // How much of the pill the light takes: more as the sound grows, and
            // all of it at full sound. Slow, for the same reason.
            val cover = (level * 1.25f).coerceAtMost(1f)
            reach += (cover - reach) * (1f - exp(-dt * 2.5f))

            // The beat only breathes: the light brightens and the tube swells a
            // little with it, and settles again. Never a movement.
            val light = (0.55f + 0.45f * level + 0.35f * kick).coerceAtMost(1f)
            glow += (light - glow) * (1f - exp(-dt * 8f))
            pulse += (kick - pulse) * (1f - exp(-dt * (if (kick > pulse) 16f else 6f)))
        }
    }

    return this.drawWithCache {
        val w = size.width
        val h = size.height
        val radius = h / 2f
        val straight = w - 2f * radius
        val core = CORE.toPx()

        // The four stretches of the outline, clockwise from the left end of the top
        // side, each with the distance along the outline at which it begins.
        val sections = if (straight > 1f && radius > 0f) buildSections(w, h, radius, straight, DIP.toPx()) else emptyList()
        val perimeter = 2f * straight + 2f * PI.toFloat() * radius

        onDrawWithContent {
            drawContent()
            if (appear <= 0.01f || sections.isEmpty()) return@onDrawWithContent

            val strength = appear * (0.80f + 0.20f * glow)
            // From a stretch of the edge in a quiet passage to all the way round at
            // full sound, always leaving a short dark gap in front of the head so
            // that the light has a front.
            val tail = perimeter * (0.28f + 0.70f * reach)
            val head = lap * perimeter
            val swell = 1f + 0.25f * pulse

            val comet = Comet(perimeter, head, tail, strength, hue)
            // Widest and faintest first, so what is brightest is on top.
            paint(sections, comet, core * 5.2f * swell, alpha = 0.16f, whiten = 0f, reachOf = 1f, blend = BlendMode.Plus)
            paint(sections, comet, core * 2.6f * swell, alpha = 0.30f, whiten = 0f, reachOf = 1f, blend = BlendMode.Plus)
            paint(sections, comet, core * 0.62f * swell, alpha = 1f, whiten = 0f, reachOf = 1f, blend = BlendMode.SrcOver)
            paint(sections, comet, core * swell, alpha = 1f, whiten = 0f, reachOf = 0.55f, blend = BlendMode.SrcOver)
            paint(sections, comet, core * 0.42f * swell, alpha = 0.85f, whiten = 0.7f, reachOf = 0.4f, blend = BlendMode.SrcOver)
        }
    }
}

// ---------------------------------------------------------------------------
// The outline, in four stretches

/** One stretch of the outline: a straight side or a half circle. */
private class Section(
    val path: Path,
    /** Distance along the outline at which it begins. */
    val start: Float,
    val length: Float,
    val straight: Boolean,
    // A straight side: the two ends of the line, a hair longer than the side.
    val ax: Float = 0f,
    val ay: Float = 0f,
    val bx: Float = 0f,
    val by: Float = 0f,
    // A half circle: its centre, its radius, and the angle at which it begins.
    val cx: Float = 0f,
    val cy: Float = 0f,
    val radius: Float = 0f,
    val firstDegrees: Float = 0f,
)

/** How much longer than its side a straight stroke is, at each end, so that no seam shows where it meets the curve. */
private const val OVERLAP = 0.8f

private fun buildSections(w: Float, h: Float, r: Float, straight: Float, dip: Float): List<Section> {
    val arc = PI.toFloat() * r
    return listOf(
        // The top side, left to right: not straight but a gentle curve that goes
        // down into the pill in the middle and comes back up to the edge where it
        // meets the ends, level there, so that it joins them without a corner.
        Section(
            path = Path().apply {
                moveTo(r - OVERLAP, 0f)
                lineTo(r, 0f)
                cubicTo(r + straight * 0.25f, 0f, r + straight * 0.25f, dip, r + straight * 0.5f, dip)
                cubicTo(r + straight * 0.75f, dip, r + straight * 0.75f, 0f, r + straight, 0f)
                lineTo(w - r + OVERLAP, 0f)
            },
            start = 0f, length = straight, straight = true,
            ax = r - OVERLAP, ay = 0f, bx = w - r + OVERLAP, by = 0f,
        ),
        // The right end, from the top round to the bottom.
        Section(
            path = Path().apply { arcTo(Rect(w - 2f * r, 0f, w, h), -90f, 180f, true) },
            start = straight, length = arc, straight = false,
            cx = w - r, cy = r, radius = r, firstDegrees = -90f,
        ),
        // The bottom side, right to left, curving up into the pill the same way.
        Section(
            path = Path().apply {
                moveTo(w - r + OVERLAP, h)
                lineTo(w - r, h)
                cubicTo(w - r - straight * 0.25f, h, w - r - straight * 0.25f, h - dip, w - r - straight * 0.5f, h - dip)
                cubicTo(w - r - straight * 0.75f, h - dip, w - r - straight * 0.75f, h, r, h)
                lineTo(r - OVERLAP, h)
            },
            start = straight + arc, length = straight, straight = true,
            ax = w - r + OVERLAP, ay = h, bx = r - OVERLAP, by = h,
        ),
        // The left end, from the bottom round to the top.
        Section(
            path = Path().apply { arcTo(Rect(0f, 0f, 2f * r, h), 90f, 180f, true) },
            start = 2f * straight + arc, length = arc, straight = false,
            cx = r, cy = r, radius = r, firstDegrees = 90f,
        ),
    )
}

// ---------------------------------------------------------------------------
// One light

/** A head at [head] and, behind it, [tail] of light that fades to nothing; [hue] is where in the palette its head is. */
private class Comet(
    val perimeter: Float,
    val head: Float,
    val tail: Float,
    val strength: Float,
    val hue: Float,
) {
    /**
     * The light at distance [s] along the outline: nothing ahead of the head, the
     * brightest at the head, and fading to nothing at [reachOf] of the tail.
     */
    fun colourAt(s: Float, alpha: Float, whiten: Float, reachOf: Float): Color {
        val length = tail * reachOf
        val behind = (((head - s) % perimeter) + perimeter) % perimeter
        if (behind > length) return palette(hue).copy(alpha = 0f)
        val u = behind / length
        val base = palette(hue + u * SPREAD * reachOf)
        val colour = if (whiten > 0f) lerp(base, Color.White, whiten) else base
        return colour.copy(alpha = ((1f - u).pow(1.5f) * strength * alpha).coerceIn(0f, 1f))
    }

    /** Whether any of the light falls between [from] and [to] along the outline. */
    fun touches(from: Float, to: Float, reachOf: Float): Boolean {
        val length = tail * reachOf
        for (shift in -1..1) {
            val end = head + shift * perimeter
            if (end >= from && end - length <= to) return true
        }
        return false
    }
}

/**
 * Lays one light down, in one width, along every stretch of the outline it
 * touches: each stretch one stroke, filled with one gradient.
 */
private fun DrawScope.paint(
    sections: List<Section>,
    comet: Comet,
    width: Float,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
    blend: BlendMode,
) {
    for (section in sections) {
        val from = if (section.straight) section.start - OVERLAP else section.start
        val to = if (section.straight) section.start + section.length + OVERLAP else section.start + section.length
        if (!comet.touches(from, to, reachOf)) continue
        val brush = if (section.straight) {
            Brush.linearGradient(
                *straightStops(comet, section, alpha, whiten, reachOf),
                start = Offset(section.ax, section.ay),
                end = Offset(section.bx, section.by),
            )
        } else {
            Brush.sweepGradient(
                *capStops(comet, section, alpha, whiten, reachOf),
                center = Offset(section.cx, section.cy),
            )
        }
        drawPath(
            path = section.path,
            brush = brush,
            style = Stroke(width = width, cap = StrokeCap.Butt),
            blendMode = blend,
        )
    }
}

/**
 * How far past the head the light takes to go dark: a short, soft leading edge,
 * so the head is a clean end to the light and not a point on it.
 */
private const val HEAD_EDGE = 7f

private fun straightStops(
    comet: Comet,
    section: Section,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
): Array<Pair<Float, Color>> {
    val from = section.start - OVERLAP
    val span = section.length + 2f * OVERLAP
    val ts = ArrayList<Float>(STRAIGHT_SAMPLES + 4)
    for (k in 0..STRAIGHT_SAMPLES) ts.add(k / STRAIGHT_SAMPLES.toFloat())
    for (shift in -1..1) {
        val at = comet.head + shift * comet.perimeter
        if (at >= from && at <= from + span) {
            ts.add((at - from) / span)
            val past = (at + HEAD_EDGE - from) / span
            if (past <= 1f) ts.add(past)
        }
    }
    ts.sort()
    return Array(ts.size) { i ->
        val t = ts[i].coerceIn(0f, 1f)
        t to comet.colourAt(from + t * span, alpha, whiten, reachOf)
    }
}

private fun capStops(
    comet: Comet,
    section: Section,
    alpha: Float,
    whiten: Float,
    reachOf: Float,
): Array<Pair<Float, Color>> {
    val arc = section.length
    // Where on a sweep gradient (0 at three o'clock, once round clockwise) the
    // point [c] along this half circle is.
    fun sweepOf(c: Float): Float {
        val degrees = section.firstDegrees + c / section.radius * (180f / PI.toFloat())
        return (((degrees % 360f) + 360f) % 360f) / 360f
    }

    val stops = ArrayList<Pair<Float, Color>>(CAP_SAMPLES + 8)
    for (k in 0..CAP_SAMPLES) {
        val c = arc * k / CAP_SAMPLES
        stops.add(sweepOf(c) to comet.colourAt(section.start + c, alpha, whiten, reachOf))
    }
    for (shift in -1..1) {
        val at = comet.head + shift * comet.perimeter
        if (at >= section.start && at <= section.start + arc) {
            val c = at - section.start
            stops.add(sweepOf(c) to comet.colourAt(at, alpha, whiten, reachOf))
            if (c + HEAD_EDGE <= arc) {
                stops.add(sweepOf(c + HEAD_EDGE) to comet.colourAt(at + HEAD_EDGE, alpha, whiten, reachOf))
            }
        }
    }
    // Three o'clock is where a sweep gradient starts and ends: the right half
    // circle goes through it, so it needs the same colour at both ends.
    if (section.firstDegrees < 0f) {
        val across = comet.colourAt(section.start + arc / 2f, alpha, whiten, reachOf)
        stops.add(0f to across)
        stops.add(1f to across)
    }
    stops.sortBy { it.first }
    return stops.toTypedArray()
}

private const val STRAIGHT_SAMPLES = 22
private const val CAP_SAMPLES = 14

// ---------------------------------------------------------------------------
// Colour and motion

/**
 * A colour from a ring of colours, [t] being how far round it is (1 is the
 * start again): blue, violet, pink, amber, green, cyan, blue.
 */
private fun palette(t: Float): Color {
    val x = (((t % 1f) + 1f) % 1f) * (PALETTE.size - 1)
    val i = x.toInt().coerceAtMost(PALETTE.size - 2)
    return lerp(PALETTE[i], PALETTE[i + 1], x - i)
}

private val PALETTE = listOf(
    Color(0xFF4285F4), // blue
    Color(0xFF9B6BFF), // violet
    Color(0xFFFF4D8D), // pink
    Color(0xFFFFB02E), // amber
    Color(0xFF34D27B), // green
    Color(0xFF22D3EE), // cyan
    Color(0xFF4285F4), // blue again: the ring closes
)

/** The tube's own thickness: thin. Everything else is a multiple of it. */
private val CORE = 0.9.dp

/** How far the long sides of the track go into the pill at their middle. */
private val DIP = 6.dp

/** How much of the palette the light shows along its length: nearly all of it, so that a long light is many colours at once. */
private const val SPREAD = 0.85f

/** Laps a second: the floor, and what the level of the sound adds to it. */
private const val BASE_LAPS = 0.30f
private const val LEVEL_LAPS = 0.55f

/** Runs of the palette a second, the same way. */
private const val BASE_DRIFT = 0.12f
private const val LEVEL_DRIFT = 0.30f
